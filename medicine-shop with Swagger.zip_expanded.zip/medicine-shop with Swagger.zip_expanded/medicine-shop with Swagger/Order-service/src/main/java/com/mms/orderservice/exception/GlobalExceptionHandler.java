package com.mms.orderservice.exception;

/**
 * This class is used to handle the Exception
 */
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestController
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	/**
	 * This method is used to handle the OrderNotFoundException
	 * @param ex exception
	 * @param request 
	 * @return
	 */
	@ExceptionHandler
	public final ResponseEntity<Object> handleOrderNotFound (OrderNotFoundException
			ex, WebRequest request){
		
		OrderNotFoundExceptionResponse response = new OrderNotFoundExceptionResponse(ex.getMessage());
		return new ResponseEntity<Object> (response,HttpStatus.BAD_REQUEST);
	}
	
	/**
	 * This method is used to handle the CartNotFoundException
	 * @param ex exception
	 * @param request 
	 * @return
	 */
	@ExceptionHandler
	public final ResponseEntity<Object> handleCartNotFound (CartNotFoundException
			ex, WebRequest request){
		
		CartNotFoundExceptionResponse response = new CartNotFoundExceptionResponse(ex.getMessage());
		return new ResponseEntity<Object> (response,HttpStatus.BAD_REQUEST);
	}
	
	/**
	 * This method is used to handle the CartAlreadyExistsException
	 * @param ex exception
	 * @param request 
	 * @return
	 */
	@ExceptionHandler
	public final ResponseEntity<Object> handleCartAlreadyExists (CartAlreadyExistsException
			ex, WebRequest request){
		
		CartAlreadyExistsExceptionResponse response = new CartAlreadyExistsExceptionResponse(ex.getMessage());
		return new ResponseEntity<Object> (response,HttpStatus.BAD_REQUEST);
	}
}
