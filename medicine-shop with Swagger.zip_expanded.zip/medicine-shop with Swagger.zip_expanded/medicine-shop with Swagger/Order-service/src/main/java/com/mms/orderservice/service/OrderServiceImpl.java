package com.mms.orderservice.service;

/**
 * This class is the Implementation of the Order Service 
 * @author Mantu Vishwakarma
 */
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.orderservice.entity.Bill;
import com.mms.orderservice.entity.Cart;
import com.mms.orderservice.entity.Order;
import com.mms.orderservice.exception.CartAlreadyExistsException;
import com.mms.orderservice.exception.CartNotFoundException;
import com.mms.orderservice.exception.OrderNotFoundException;
import com.mms.orderservice.repository.BillRepository;
import com.mms.orderservice.repository.CartRepository;
import com.mms.orderservice.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private BillRepository billRepository;

	private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Override
	public Order placeOrder(Order order) {

		// Saving Order to Database
		Order placedOrder = orderRepository.save(order);
		log.info("------Placed Order-------"+order);

		// Generating the bill
		Bill bill = new Bill();
		bill.setOrderId(order.getOrderId());
		bill.setBillAmount(order.getTotalAmount());

		billRepository.save(bill);
		log.info("-----Generated Bill---------"+ bill);
		
		// Returning order
		return placedOrder;
	}

	@Override
	public Order viewOrder(Long orderId) throws OrderNotFoundException {

		// Fetching Order from Database
		Order retrievedOrder = orderRepository.findOrderByOrderId(orderId);
		
		// Checking if Order Exists
		if (retrievedOrder == null) {
			log.error("---Order Not Found With Id---"+ orderId);
			// Throw OrderNotFoundException
			throw new OrderNotFoundException("order not found with order id : " + orderId);
		}
		log.info("----Fetched Order ----"+retrievedOrder);
		// Returning Order
		return retrievedOrder;
	}

	@Override
	public List<Order> viewAllCustomerOrders(Long customerId) {

		// Fetching Order List
		List<Order> orders = new ArrayList<>();
		orders = orderRepository.findOrderByUserId(customerId);

		log.info("----Fetched Orders ----"+orders);
		// Returning Order List
		return orders;
	}

	@Override
	public List<Order> viewAllOrders() {

		// Fetching Order List
		List<Order> orders = null;
		orders = orderRepository.findAll();

		log.info("----Fetched Orders ----"+orders);
		// Returning Order List
		return orders;
	}

	@Override
	public Order updateOrder(Order order) {

		// Updating Order
		Order updatedOrder = orderRepository.save(order);

		log.info("----Updated Orders ----"+updatedOrder);
		// Returning Updated Order
		return updatedOrder;
	}

	@Override
	public void cancelOrder(Long orderId) {

		// Fetching Order from Database
		Order order = orderRepository.findOrderByOrderId(orderId);

		// Checking if Order Exists
		if (order == null) {
			
			log.error("---Order Not Found With Id---"+ orderId);
			// Throwing the OrderNotFoundException
			throw new OrderNotFoundException("Order Doesn't Exists with Id : " + orderId);
		}

		log.info("----Deleted Orders ----"+order);
		// Cancel Order
		orderRepository.deleteById(orderId);
	}

	@Override
	public Bill viewBill(Long orderId) {

		// Fetching Bill
		 Bill bill = billRepository.findBillByOrderId(orderId); 

		 log.info("-----Fetched Bill---------"+ bill);
		// Returning Bill
		return bill;
	}

	@Override
	public Cart addToCart(Cart cart) {

		Cart fetchedCart = cartRepository.findCartByProductId(cart.getProductId());
		if(fetchedCart != null) {
			// Throw CartAlreadyExistsException 
			log.error("---product Already Exists in the cart----");
			throw new CartAlreadyExistsException("product Already Exists in the cart");
		}
		// Saving Cart to Database
		Cart savedCart = cartRepository.save(cart);

		log.info("----Saved Cart---"+savedCart);
		// Returning Cart
		return savedCart;
	}

	@Override
	public Cart viewCart(Long cartId) {

		// Fetching Cart
		Cart cart = cartRepository.findCartByCartId(cartId);

		// Checking if Cart Exists
		if(cart == null) {
			log.error("-----Cannot find Cart with Id : "+ cartId);
			// Throw CartNotFoundException
			throw new CartNotFoundException("Cannot find Cart with Id : "+ cartId);
		}
		
		log.info("---FetchedCart--"+cart);
		// Returning Cart
		return cart;
	}

	@Override
	public List<Cart> viewAllCartByCustomer(Long userId) {
		
		// Fetching Cart 
		 List<Cart> cart = cartRepository.findCartByUserId(userId);
		 
		 log.info("---All Carts---"+cart);
		 // Returning Cart List
		return cart;
	}
	
	@Override
	public void deleteCart(Long cartId) {

		// Fetching Cart
		Cart cart = cartRepository.findCartByCartId(cartId);

		// Checking if Cart Exists
		if (cart == null) {
			
			log.error("-----Cannot find Cart with Id : "+ cartId);
			// Throwing CartNotFoundException
			throw new CartNotFoundException("Cart Not Found ");
		}

		log.info("---Deleted Cart---"+cart);
		// Deleting the cart
		cartRepository.deleteById(cartId);

	}


}
