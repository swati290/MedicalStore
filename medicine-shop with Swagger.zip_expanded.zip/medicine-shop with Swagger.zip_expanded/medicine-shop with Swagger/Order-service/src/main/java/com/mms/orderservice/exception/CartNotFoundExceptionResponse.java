package com.mms.orderservice.exception;

/**
 * IT will be used as Response to Handle the CartNotFoundException
 * @author Mantu Vishwakarma
 *
 */
public class CartNotFoundExceptionResponse {

	private String productId;

	/**
	 * This method is used to instantiate 
	 * @param productId 
	 */
	public CartNotFoundExceptionResponse(String productId) {
		super();
		this.productId = productId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	
}
