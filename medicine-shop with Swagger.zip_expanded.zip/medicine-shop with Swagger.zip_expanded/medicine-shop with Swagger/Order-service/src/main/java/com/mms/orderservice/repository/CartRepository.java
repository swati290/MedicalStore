package com.mms.orderservice.repository;
/**
 * This interface Repository is used to perform the CRUD Operation in the Database
 * @author Mantu Vishwakarma
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mms.orderservice.entity.Cart;
@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {

	/**
	 * This method is used to save the Cart in the Database		
	 */
	public Cart save(Cart cart);
	
	/**
	 * This method is used to find the cart from the Database
	 * @param cartId of the Cart
	 * @return the Cart
	 */
	public Cart findCartByCartId(Long cartId);
	
	/**
	 * This method is used to find Cart from Database
	 * @param productId of the product in the Cart
	 * @return the Cart
	 */
	public Cart findCartByProductId(long productId);
	
	/**
	 * This method is used to find the Cart from Database
	 * @param userId of the User to which Cart belongs
	 * @return the List of Carts
	 */
	public List<Cart> findCartByUserId(Long userId);
}
