package com.mms.orderservice.repository;
/**
 * This the Repository Interface used to perform CRUD operation in the database
@author Mantu Vishwakarma
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mms.orderservice.entity.Bill;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {

	/**
	 * This method is used to find the Order 
	 * @param orderId to find the Order
	 * @return the Order
	 */
	public Bill findBillByOrderId(Long orderId);
}
