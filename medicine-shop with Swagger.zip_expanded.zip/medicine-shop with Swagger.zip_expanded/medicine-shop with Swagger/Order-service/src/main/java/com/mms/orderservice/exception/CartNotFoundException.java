package com.mms.orderservice.exception;

/**
 * This is used to Throw Exception if Cart Not Found
 * @author Mantu Vishwakarma
 *
 */
public class CartNotFoundException  extends RuntimeException{


	/**
	 * This method is used to instantiate class with No argument
	 */
	public CartNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * This method is used to instantiate class with argument
	 * @param message to be thrown
	 */
	public CartNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
