package com.mms.orderservice.repository;

/**
 * This Interface is used to perform the CRUD Operation in the Database
 * @author Mantu Vishwakarma
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.mms.orderservice.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

	/**
	 * This method is  used to find the Order from the Database
	 * @param orderId of the Order
	 * @return the Order
	 */
	public Order findOrderByOrderId(Long orderId);
	
	/**
	 * This method is used to find the Orders from the Database
	 * @param userId of the Order to which it belongs
	 * @return the List of Orders
	 */
	public List<Order> findOrderByUserId(Long userId);
}
