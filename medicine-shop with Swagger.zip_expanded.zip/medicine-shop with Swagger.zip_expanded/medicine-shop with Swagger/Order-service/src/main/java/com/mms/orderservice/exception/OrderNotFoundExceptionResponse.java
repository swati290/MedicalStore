package com.mms.orderservice.exception;

/**
 * IT will be used as Response to Handle the OrderNotFoundException
 * @author Mantu Vishwakarma
 *
 */
public class OrderNotFoundExceptionResponse {

	public String orderId;

	/**
	 * This method is used to instantiate with parameter
	 * @param orderId
	 */
	public OrderNotFoundExceptionResponse(String orderId) {
		super();
		this.orderId = orderId;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	
	
	
}
