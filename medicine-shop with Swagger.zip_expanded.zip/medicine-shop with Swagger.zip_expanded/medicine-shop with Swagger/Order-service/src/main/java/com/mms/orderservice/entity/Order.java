package com.mms.orderservice.entity;
/**
 * This is the DTO layer's Order module which will be transfered from one to another layer
 * @author Mantu Vishwakarma
 */
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/*@Data
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor*/
@Entity
@Table(name ="orders")
public class Order {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private Long orderId;
	
	private Date dateTime;
	
	@NotNull(message = "Provide the Total Amount")
	private Long totalAmount;
	
	@NotNull(message = "Provide the User Id")
	private Long userId;
	
	@NotNull(message = "Provide the Product Id")
	private Long productId;

	public Order() {
		super();
	}
	
	public Order(Long orderId, Date dateTime,
			Long totalAmount,Long userId, Long productId) {
		super();
		this.orderId = orderId;
		this.dateTime = dateTime;
		this.totalAmount = totalAmount;
		this.userId = userId;
		this.productId = productId;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", dateTime=" + dateTime + ", totalAmount=" + totalAmount + ", userId="
				+ userId + ", productId=" + productId + "]";
	}
	
	
	
}
