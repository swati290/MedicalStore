package com.mms.orderservice.entity;

/**
 * This class is used to create the cart
 * @author Mantu Vishwakarma
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name="carts")
public class Cart {
	
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private Long cartId;
	
	@NotNull(message = "Provide the Cart Value")
	private Long cartValue;
	
	@NotNull(message = "Provide the User Id")
	private Long userId;
	
	@NotNull(message = "Provide the product Id")
	private Long productId;

	public Cart() {
		super();
	}
	
	public Cart(Long cartId,Long cartValue, Long userId, Long productId) {
		super();
		this.cartId = cartId;
		this.cartValue = cartValue;
		this.userId = userId;
		this.productId = productId;
	}

	public Long getCartId() {
		return cartId;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}
	
	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCartValue() {
		return cartValue;
	}

	public void setCartValue(Long cartValue) {
		this.cartValue = cartValue;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", cartValue=" + cartValue + ", userId=" + userId + ", productId=" + productId
				+ "]";
	}

	
	

}
