package com.mms.orderservice.exception;
/**
 * This is used to Throw Exception if Cart Already Exists
 * @author Mantu Vishwakarma
 *
 */
public class CartAlreadyExistsException  extends RuntimeException{

	/**
	 * This method is used to instantiate class with No argument
	 */
	public CartAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * This method is used to instantiate with Parameter
	 * @param message to be shown
	 */
	public CartAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
