package com.mms.orderservice.service;

import java.util.List;

import com.mms.orderservice.entity.Bill;
import com.mms.orderservice.entity.Cart;
import com.mms.orderservice.entity.Order;

/**
 * All the business logic will be applied here
 * @author Mantu Vishwakarma
 *
 */
public interface OrderService {

	/**
	 * This method is used to place an order 
	 * @param order to be placed
	 * @return the placed Order
	 */
	public Order placeOrder(Order order);
	
	/**
	 * This method is used to view the particular order
	 * @param orderId to be view
	 * @return the order 
	 */
	public Order viewOrder(Long orderId) throws Exception;
	
	/**
	 * This method is used to view all the orders placed by the particular customer in 
	 * the System that are available in the database 
	 * @return the list of orders of the particular Customer available in the database
	 */
	public List<Order> viewAllCustomerOrders(Long customerId) throws Exception;
	
	/**
	 * This method is used to view all the Orders available in the system/database 
	 * @return the list of orders available in the System
	 */
	public List<Order> viewAllOrders() throws Exception;
	
	/**
	 * This method is used to  update the Order in the database
	 * @param order to be updated
	 * @return the updated order
	 */
	
	public Order updateOrder(Order order) throws Exception;
	
	/**
	 * This method is used to cancel the order in the System 
	 * It will delete the record from database
	 * @param orderId to be cancel
	 */
	public void cancelOrder(Long orderId) throws Exception;
	
	/**
	 * This method is used to add the product items in the cart
	 *  which customer can later on go through with.
	 * @param cart to be added
	 * @return the cart added in database
	 */
	public Cart addToCart(Cart cart)throws Exception;
	
	/**
	 * This method is used to used to view the bill of the particular order
	 * @param orderId of the order
	 * @return
	 */
	public Bill viewBill(Long orderId) throws Exception;
	
	/**
	 * This method is used to view the cart 
	 * @param cartId of the cart
	 * @return the cart
	 */
	public Cart viewCart(Long cartId) throws Exception;
	
	/**
	 * This method is used to view all the cart in the database corresponding to 
	 * particular User
	 * @param userId of the Customer
	 * @return the Cart
	 */
	public List<Cart> viewAllCartByCustomer(Long userId);
	
	/**
	 * This method is used to delete the cart
	 * @param cartId of the cart
	 */
	public void deleteCart(Long cartId);
}


