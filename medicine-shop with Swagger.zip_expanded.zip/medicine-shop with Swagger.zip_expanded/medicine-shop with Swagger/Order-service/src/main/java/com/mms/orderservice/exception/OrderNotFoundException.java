package com.mms.orderservice.exception;

/**
 * This is used to Throw Exception if Order Not Found
 * @author Mantu Vishwakarma
 *
 */
public class OrderNotFoundException extends RuntimeException{


	private static final long serialVersionUID = 1L;
	
	/**
	 * This method is used to instantiate 
	 */
	public OrderNotFoundException() {
		super();
	}
	
	/**
	 * This method is used to instantiate with arguments
	 * @param error
	 */
	public OrderNotFoundException(String error) {
		super(error);
	}

}
