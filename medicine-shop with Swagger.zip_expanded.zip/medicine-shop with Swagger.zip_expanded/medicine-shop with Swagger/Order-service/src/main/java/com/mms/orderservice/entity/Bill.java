package com.mms.orderservice.entity;
/**
 * This class is used to make the bill 
 * @author Mantu Vishwakarma
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name ="bills")
public class Bill {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private Long billId;
	
	@NotNull(message = "Provide the Order Id")
	private Long orderId;
	
	@NotNull(message = "Provide the Bill Amount")
	private Long billAmount;
	
	private String particular;

	public Bill() {
		
	}
	
	public Bill(Long billId,Long orderId, Long billAmount, String particular) {
		super();
		this.billId = billId;
		this.orderId = orderId;
		this.billAmount = billAmount;
		this.particular = particular;
	}

	public Long getBillId() {
		return billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(Long billAmount) {
		this.billAmount = billAmount;
	}

	public String getParticular() {
		return particular;
	}

	public void setParticular(String particular) {
		this.particular = particular;
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", orderId=" + orderId + ", billAmount=" + billAmount + ", particular="
				+ particular + "]";
	}
	
	
	
}
