package com.mms.orderservice.entity;

/**
 * This is the POJO class used to store the Product
 * @author Mantu Vishwakarma
 *
 */

public class Product {

	private Long productId;
	private String productName;
	private Long productQty;
	private Long productPrize;
	private String description;
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Long getProductQty() {
		return productQty;
	}
	public void setProductQty(Long productQty) {
		this.productQty = productQty;
	}
	public Long getProductPrize() {
		return productPrize;
	}
	public void setProductPrize(Long productPrize) {
		this.productPrize = productPrize;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
