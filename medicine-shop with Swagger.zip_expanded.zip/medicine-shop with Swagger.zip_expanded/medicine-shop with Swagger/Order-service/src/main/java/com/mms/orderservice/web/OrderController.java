package com.mms.orderservice.web;
/**
 * This is the Controller Class used to access the API end points
 * @author Mantu Vishwakarma
 */
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mms.orderservice.entity.Bill;
import com.mms.orderservice.entity.Cart;
import com.mms.orderservice.entity.Order;
import com.mms.orderservice.service.MapValidationErrorService;
import com.mms.orderservice.service.OrderService;
import com.mms.orderservice.service.OrderServiceImpl;

@RequestMapping("/orderservice/api")
@RestController
@CrossOrigin
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	@Autowired
	private MapValidationErrorService mapValidationErrorService;
	
	/*------------------------------------------------------------------------
	 *                      ORDER MANAGEMENT
	 * ------------------------------------------------------------------------                     
	 */
	
	/**
	 * This method is used to place the Order in the System
	 * @param order 
	 * @param result
	 * @return
	 */
	@PostMapping("/placeorder")
	public ResponseEntity<?> placeOrder(@Valid @RequestBody Order order,BindingResult result) {
		
		ResponseEntity<?> error = mapValidationErrorService.mapValidationError(result);
		if(error != null) {
			return error;
		}
		
		Order savedOrder  = orderService.placeOrder(order);
		return new ResponseEntity<Order>(savedOrder, HttpStatus.CREATED);
	}
	
	/**
	 * This method is used to fetch Order based on Order ID
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/vieworder/{id}")
	public ResponseEntity<Order> getOrder(@PathVariable Long id) throws Exception {
		 Order savedOrder  = orderService.viewOrder(id);
		return new ResponseEntity<Order>(savedOrder, HttpStatus.OK);
	}
	
	/**
	 * This method is used to view All the Order of the Specific User
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/vieworder/all/{userId}")
	public ResponseEntity<?> viewCustomersOrder(@PathVariable Long userId) throws Exception{
		
		List<Order> orders = new ArrayList<>();
		orders = orderService.viewAllCustomerOrders(userId);
		
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}
	
	/**
	 * This method is used to get all the Orders in the System
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/all")
	public ResponseEntity<List<Order>> viewAllOrder() throws Exception{
		List<Order> orders = new ArrayList<>();
		orders = orderService.viewAllOrders();
		return new ResponseEntity<List<Order>>( orders, HttpStatus.OK);
		
	}
	
	/**
	 * This method is used to update the Order
	 * @param order
	 * @param result
	 * @return
	 * @throws Exception
	 */
	@PatchMapping("/update")
	public ResponseEntity<?> updateOrder(@Valid @RequestBody Order order, BindingResult result) throws Exception{
		
		ResponseEntity<?> error = mapValidationErrorService.mapValidationError(result);
		if(error != null) {
			return error;
		}
		
		Order updatedOrder = orderService.updateOrder(order);
		return new ResponseEntity<Order> (updatedOrder, HttpStatus.OK);
	}
	
	/**
	 * This method is used to delete the Orders
	 * @param orderId
	 * @return
	 * @throws Exception
	 */
	@DeleteMapping("/delete/{orderId}")
	public ResponseEntity<?> cancelOrder(@PathVariable Long orderId) throws Exception{
		orderService.cancelOrder(orderId);
		 return new ResponseEntity<String>("Order deleted Successfully :"+orderId,HttpStatus.OK);
	}
	
	
	/*------------------------------------------------------------------------
	 *                      CART & BILL MANAGEMENT 
	 * ------------------------------------------------------------------------                     
	 */
	
	
	/**
	 * This method is used to add the Cart
	 * @param cart
	 * @param result
	 * @return
	 * @throws Exception
	 */
	@PostMapping("cart/addcart")
	public ResponseEntity<?> addToCart(@Valid @RequestBody Cart cart, BindingResult result) throws Exception{
		
		ResponseEntity<?> error = mapValidationErrorService.mapValidationError(result);
		if(error != null) {
			return error;
		}
		
		Cart savedCart = orderService.addToCart(cart);
		return new ResponseEntity<Cart> (savedCart,HttpStatus.CREATED);
	}
	
	/**
	 * This method is used to view the Cart based on Cart Id
	 * @param cartId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/viewcart/{cartId}")
	public ResponseEntity<?> viewCart(@PathVariable Long cartId) throws Exception{
		Cart cart = orderService.viewCart(cartId);
		return new ResponseEntity<Cart>(cart, HttpStatus.OK);
	}
	
	/**
	 * This method is used to view all the Carts of the Specific User
	 * @param userId
	 * @return
	 */
	@GetMapping("/viewcart/all/{userId}")
	public ResponseEntity<?> viewAllCart(@PathVariable Long userId){
		
		List<Cart> carts = new ArrayList<>();
		carts = orderService.viewAllCartByCustomer(userId);
		return new ResponseEntity<List<Cart>>(carts, HttpStatus.OK);
		
	}
	
	/**
	 * This method is used to delete the Cart
	 * @param cartId
	 * @return
	 */
	@DeleteMapping("cart/delete/{cartId}")
	public ResponseEntity<?> deleteCart(@PathVariable Long cartId){
		
		orderService.deleteCart(cartId);
		return new ResponseEntity<String>("Cart with Id "+cartId+ "Deleted Successfully..",HttpStatus.OK);
	}
	
	/**
	 * This method id used to view the bill based on Order Id
	 * @param orderId
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/viewbill/{orderId}")
	public ResponseEntity<?> viewBill(@PathVariable Long orderId) throws Exception{
		
		Bill bill = orderService.viewBill(orderId);
		return new ResponseEntity<Bill>(bill, HttpStatus.OK);
	}
	
}
