package com.mms.orderservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mms.orderservice.entity.Bill;
import com.mms.orderservice.entity.Cart;
import com.mms.orderservice.entity.Order;
import com.mms.orderservice.exception.CartAlreadyExistsException;
import com.mms.orderservice.exception.CartNotFoundException;
import com.mms.orderservice.exception.OrderNotFoundException;
import com.mms.orderservice.repository.BillRepository;
import com.mms.orderservice.repository.CartRepository;
import com.mms.orderservice.repository.OrderRepository;

public class OrderServiceTest {

	@Mock
	private OrderRepository orderRepository;
	
	@Mock
	private BillRepository billRepository;
	
	@Mock
	private CartRepository cartRepository;
	
	@InjectMocks
	private OrderServiceImpl orderServiceImpl;
	
	
	@BeforeEach
	void setUp() throws Exception {

	MockitoAnnotations.openMocks(this);// invoke mocks
	
	}
	

	@Test
	public void test_PlaceOrder_GivenOrder_ShouldReturnAddedOrder() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		Bill bill = new Bill(Long.valueOf(1),order.getOrderId(),order.getTotalAmount(),null);
		when(orderRepository.save(order)).thenReturn(order);
		when(billRepository.save(bill)).thenReturn(bill);
		assertEquals(order,orderServiceImpl.placeOrder(order));
	}
	
	@Test
	public void test_ViewOrder_Given_OrderId_ShouldReturn_Order() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		when(orderRepository.findOrderByOrderId(order.getOrderId())).thenReturn(order);
		assertEquals(order,orderServiceImpl.viewOrder(order.getOrderId()));
	}
	
	@Test
	public void test_ViewOrder_Given_OrderId_ShouldThrow_OrderNotFoundException() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		when(orderRepository.findOrderByOrderId(order.getOrderId())).thenReturn(null);
		assertThrows(OrderNotFoundException.class,() -> orderServiceImpl.viewOrder(order.getOrderId()));
	}

	@Test
	public void test_ViewAllCustomerOrder_Given_CustomerId_ShouldReturn_ListOfOrders() {
		List<Order> orders = new ArrayList<>();
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		orders.add(order);
		when(orderRepository.findOrderByUserId(order.getUserId())).thenReturn(orders);
		assertEquals(orders, orderServiceImpl.viewAllCustomerOrders(order.getUserId()));
	}
	
	@Test
	public void test_ViewAllOrder_ShouldReturn_ListOfOrders() {
		List<Order> orders = new ArrayList<>();
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		orders.add(order);
		when(orderRepository.findAll()).thenReturn(orders);
		assertEquals(orders, orderServiceImpl.viewAllOrders());
	}
	
	@Test
	public void test_UpdateOrder_GivenOrder_ShouldReturn_UpdatedOrder() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		Order updatedOrder = new Order(Long.valueOf(1),new Date(),Long.valueOf(4000),Long.valueOf(3),Long.valueOf(1));
		when(orderRepository.save(updatedOrder)).thenReturn(updatedOrder);
		assertEquals(updatedOrder, orderServiceImpl.updateOrder(updatedOrder));
	}
	
	@Test
	public void test_CancelOrder_Given_OrderId_ShouldDeleteThatOrder() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		when(orderRepository.findOrderByOrderId(order.getOrderId())).thenReturn(order);
		orderServiceImpl.cancelOrder(order.getOrderId());
		verify(orderRepository, times(1)).deleteById(order.getOrderId());
	}
	
	@Test
	public void test_CancelOrder_Given_OrderId_ShouldThrow_OrderNotFoundException() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		when(orderRepository.findOrderByOrderId(order.getOrderId())).thenReturn(null);
		assertThrows(OrderNotFoundException.class,() -> orderServiceImpl.cancelOrder(order.getOrderId()));
	}
	
	@Test
	public void test_ViewBill_GivenOrderId_ShouldReturnBillOfThatOrder() {
		Order order = new Order(Long.valueOf(1),new Date(),Long.valueOf(3500),Long.valueOf(3),Long.valueOf(1));
		Bill bill = new Bill(Long.valueOf(1),order.getOrderId(),order.getTotalAmount(),null);
		when(billRepository.findBillByOrderId(order.getOrderId())).thenReturn(bill);
		assertEquals(bill,orderServiceImpl.viewBill(order.getOrderId()));
	}
	
	@Test
	public void test_AddToCart_GivenCart_ShouldReturnSavedCart() {
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		when(cartRepository.findCartByProductId(cart.getProductId())).thenReturn(null);
		when(cartRepository.save(cart)).thenReturn(cart);
		assertEquals(cart,orderServiceImpl.addToCart(cart));
	}
	
	@Test
	public void test_AddToCart_Given_Cart_ShouldThrow_CartAlreadyExistsException() {
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		when(cartRepository.findCartByProductId(cart.getProductId())).thenReturn(cart);
		assertThrows(CartAlreadyExistsException.class,() -> orderServiceImpl.addToCart(cart));
	}
	
	@Test
	public void test_ViewCart_Given_CartId_ShouldReturn_Cart() {
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		when(cartRepository.findCartByCartId(cart.getCartId())).thenReturn(cart);
		assertEquals(cart,orderServiceImpl.viewCart(cart.getCartId()));
	}
	
	@Test
	public void test_ViewCart_Given_CartId_ShouldThrow_CartNotFoundException() {
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		when(cartRepository.findCartByCartId(cart.getCartId())).thenReturn(null);
		assertThrows(CartNotFoundException.class,() -> orderServiceImpl.viewCart(cart.getCartId()));
	}
	
	@Test
	public void test_ViewAllCartByCustomer_Given_CustomerId_ShouldReturn_ListOfCarts() {
		List<Cart> carts = new ArrayList<>();
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		carts.add(cart);
		when(cartRepository.findCartByUserId(cart.getUserId())).thenReturn(carts);
		assertEquals(carts, orderServiceImpl.viewAllCartByCustomer(cart.getUserId()));
	}
	
	@Test
	public void test_DeleteCart_Given_CartId_ShouldDeleteThatCart() {
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		when(cartRepository.findCartByCartId(cart.getCartId())).thenReturn(cart);
		orderServiceImpl.deleteCart(cart.getCartId());
		verify(cartRepository, times(1)).deleteById(cart.getCartId());
	}
	
	@Test
	public void test_DeleteCart_Given_CartId_ShouldThrowCartNotFoundException() {
		Cart cart = new Cart(Long.valueOf(1),Long.valueOf(1000),Long.valueOf(1),Long.valueOf(5));
		when(cartRepository.findCartByCartId(cart.getCartId())).thenReturn(null);
		assertThrows(CartNotFoundException.class,() -> orderServiceImpl.deleteCart(cart.getCartId()));
	}
}
