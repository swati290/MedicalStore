package com.mms.userservice.serviceImpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.mms.userservice.entities.User;
import com.mms.userservice.exception.InvalidCredentialException;
import com.mms.userservice.exception.UserNameExistsException;
import com.mms.userservice.repository.UserRepository;
import com.mms.userservice.service.UserServiceImpl;



class UserServiceImplTest {

	  @Mock
	    private UserRepository userRepository;
	    
	    @InjectMocks
	    private UserServiceImpl userServiceImpl;
	    
	    
	    @BeforeEach
	    void setUp() throws Exception {
	    	 MockitoAnnotations.openMocks(this);// invoke mocks
	    }
	 

	  
	    
	@Test
	public void registerUsertest() 
	{
		User user = new User(Long.valueOf(1),"abc","pqr","swati","swati","admin","asdsad","abc@gmail.com",Long.valueOf(10));
		
		when(userRepository.save(user)).thenReturn(user);
		
		User savedUser=userServiceImpl.registerUser(user);
		
		assertEquals(user,savedUser);
		
		
	}
	
	
	
	 public void test_DeleteUser() {
	        User user = new User(Long.valueOf(1),"abc","pqr","swati","swati","admin","asdsad","abc@gmail.com",Long.valueOf(10));
	        userServiceImpl.deleteUserByUserName(user.getUserName());
	        verify(userRepository, times(1)).delete(user);
	    }
	

		@Test
		public void updateUserTest() {
			User user = new User(Long.valueOf(1),"abc","pqr","swati","swati","admin","asdsad","abc@gmail.com",Long.valueOf(10));
		
			when(userRepository.save(user)).thenReturn(user);
			
			User updateUser=userServiceImpl.registerUser(user);
			
			assertEquals(user,updateUser);
			
			
		}
		
		
		

		 @Test
		    public void ViewAll() {
		        List<User> user = new ArrayList<User>();
		        user.add(new User(Long.valueOf(1),"abc","pqr","swati","swati","admin","asdsad","abc@gmail.com",Long.valueOf(10)));
		        user.add(new User(Long.valueOf(2),"abcd","pqrs","swati1","swati1","admin1","asdsad1","abcd@gmail.com",Long.valueOf(10)));
		        when(userRepository.findAll()).thenReturn(user);
		        assertEquals(user,userServiceImpl.findAll());
		    }
	
		 
	
			/*
			 * @Test public void Login() { User user = new
			 * User(Long.valueOf(1),"abc","pqr","swati123","swati123","admin","asdsad",
			 * "abc@gmail.com",Long.valueOf(10));
			 * when(userRepository.findByUserName(user.getUserName())).thenReturn(user);
			 * User loginUser=userServiceImpl.authenticateUser(user.getUserName(),
			 * user.getPwd()); assertEquals(user, loginUser);
			 * 
			 * }
			 */
	
	
	 @Test
	      public void RegisterUserAlreadyExist_Should() {
	        User user = new User(Long.valueOf(1),"abc","pqr","swati","swati","admin","asdsad","abc@gmail.com",Long.valueOf(10));
	        when(userRepository.findByUserName(user.getUserName())).thenReturn(user);
	        assertThrows(UserNameExistsException.class, () -> userServiceImpl.registerUser(user));
	    }
	    
	 
		/*
		 * @Test public void AuthenticateUserInvalidLoginCredential() { User user = new
		 * User(Long.valueOf(1),"abc","pqr","swati123","swati123","admin","asdsad",
		 * "abc@gmail.com",Long.valueOf(10));
		 * when(userRepository.findByUserName(user.getUserName())).thenReturn(null);
		 * assertThrows(InvalidCredentialException.class, ()
		 * ->userServiceImpl.authenticateUser(user.getUserName(),user.getPwd())); }
		 */
		
		
	}
	

	
		
	


