package com.mms.userservice.exception;

public class UserNameExistsExceptionResponce {

	private String userName;

	public UserNameExistsExceptionResponce() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public UserNameExistsExceptionResponce(String userName) {
		super();
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
