package com.mms.userservice.exception;


public class UserNameExistsException extends RuntimeException 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNameExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNameExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
