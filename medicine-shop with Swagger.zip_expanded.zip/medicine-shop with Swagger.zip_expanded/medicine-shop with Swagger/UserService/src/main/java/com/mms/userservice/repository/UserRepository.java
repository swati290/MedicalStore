package com.mms.userservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mms.userservice.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	public User findByUserName(String userName);

    public void deleteByUserName(String userName);
    
    public List<User> findAll();

	//User findByUserName(String userName);

	//public User userlogin(String username, String pwd);

	
	
	//public User registerUser(User user);
}
