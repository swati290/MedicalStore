package com.mms.userservice.service;

import java.util.List;

import javax.security.auth.login.LoginException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import com.mms.userservice.entities.User;
import com.mms.userservice.exception.InvalidCredentialException;
import com.mms.userservice.exception.UserNameExistsException;
import com.mms.userservice.exception.UserNotFoundException;
import com.mms.userservice.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	@Override
	public User registerUser(User user) {
		
		
		User existsUser=userRepository.findByUserName(user.getUserName());
		if(existsUser!=null)
		{
			log.error("-----User Already Exists--");
			throw new UserNameExistsException("User Already Exit");
		}
		log.info("----User Saved Successfully--");
		return userRepository.save(user);
	}
	
	
	
	@Override
	
	public User findByUserName(String userName)
	{
		User user1 = userRepository.findByUserName(userName);
		if(user1==null)
		{
			log.error("-----User Not Found --");
			throw new UserNotFoundException("User Not Found");
		}
		
		log.info("-----User Found Successfully---");
		return userRepository.findByUserName(userName);
	}

	
	/*
	 * @Override public User authenticateUser(String userName, String pwd) {
	 * 
	 * User user = userRepository.findByUserName(userName); if(user==null) { throw
	 * new InvalidCredentialException("Invalid Credentials"); }
	 * 
	 * if (user.getPwd().equals(pwd)) {
	 * 
	 * return user; }
	 * 
	 * 
	 * else {
	 * 
	 * throw new InvalidCredentialException("Invalid Credentials");
	 * 
	 * }
	 * 
	 * 
	 * }
	 */

		

		
		@Override
	    public User updateUser(User user) {
	       
	        User oldUser = userRepository.findByUserName(user.getUserName());
	      
	        user.setUserId(oldUser.getUserId());
	        oldUser = user;
	        
	        log.info("-----User Saved Successfully---");
	        return userRepository.save(oldUser);
	    }


		@Override
		public void deleteUserByUserName(String userName) {
			// TODO Auto-generated method stub
			
			log.info("-----User Deleted Successfully---");
			userRepository.deleteByUserName(userName);
		}


		@Override
		public List<User> findAll() {
			// TODO Auto-generated method stub
			List<User> user1 = userRepository.findAll();
			log.info("------All Users -----");
			return user1;
		
		}


	
		
		
		

		
		

	
	


	
	
	

}
