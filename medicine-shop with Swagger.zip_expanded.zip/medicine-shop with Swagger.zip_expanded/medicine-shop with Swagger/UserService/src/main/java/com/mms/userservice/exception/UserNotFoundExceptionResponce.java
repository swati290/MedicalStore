package com.mms.userservice.exception;

public class UserNotFoundExceptionResponce {

	
	private String userName;

	public UserNotFoundExceptionResponce() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNotFoundExceptionResponce(String userName) {
		super();
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
