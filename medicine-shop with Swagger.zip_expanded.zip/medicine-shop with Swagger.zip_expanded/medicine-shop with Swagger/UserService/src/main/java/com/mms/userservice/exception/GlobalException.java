package com.mms.userservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestController
@ControllerAdvice
public class GlobalException extends ResponseEntityExceptionHandler
{
       
	
	
	
	@ExceptionHandler
	public final ResponseEntity<Object> handleInvalidCredential(InvalidCredentialException
	ex, WebRequest request){
	InvalidCredentialExceptionResponce response = new InvalidCredentialExceptionResponce(ex.getMessage());
	return new ResponseEntity<Object> (response,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler
	public final ResponseEntity<Object> handleUserNameExists(UserNameExistsException
	ex, WebRequest request){
	UserNameExistsExceptionResponce response = new UserNameExistsExceptionResponce(ex.getMessage());
	return new ResponseEntity<Object> (response,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler
	public final ResponseEntity<Object> handleUserNotFound(UserNotFoundException
	ex, WebRequest request){
	UserNotFoundExceptionResponce response = new UserNotFoundExceptionResponce(ex.getMessage());
	return new ResponseEntity<Object> (response,HttpStatus.BAD_REQUEST);
	}
	
	
	
	
	/*
	@Override
	public Customer loginCustomer(String userName, String pwd, HttpSession session) {
	// check for null values for Username
	if (userName == null) {
	throw new InValidUsernameException("InValid null Username");
	}
	// check for null values of password
	if (pwd == null) {
	throw new InValidPwdException("InValid Password ");
	}
	// fetch the customer from userName
	Customer customer = customerRepository.findCustomerByUserName(userName);
	if (customer == null) {
	session = null;
	// throw Invalid userName Exception
	throw new InValidUsernameException(" Username " + userName + " is InValid");
	}

	 // checking the password
	if (customer.getPwd().equals(pwd)) {

	 // creating session
	session.setAttribute("userType", "Customer");
	session.setAttribute("userName", userName);

	 // returning the loggedIn Customer
	return customer;
	} else {
	session = null;
	// throw Invalid password Exception
	throw new InValidPwdException("InValid Password");
	}
	}*/
	
}
