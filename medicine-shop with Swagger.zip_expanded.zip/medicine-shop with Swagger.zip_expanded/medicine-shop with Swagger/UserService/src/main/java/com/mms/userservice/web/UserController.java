package com.mms.userservice.web;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mms.userservice.entities.AuthRequest;
import com.mms.userservice.entities.User;
import com.mms.userservice.service.MapValidationErrorService;
import com.mms.userservice.service.UserService;
import com.mms.userservice.service.UserServiceImpl;
import com.mms.userservice.util.JwtUtil;

@RestController
@CrossOrigin
@RequestMapping("/userservice/api")
public class UserController {

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@PostMapping("/save")
	public ResponseEntity<?> registerUser(@Valid @RequestBody User user, BindingResult result) {
		ResponseEntity<?> errorMap = mapValidationErrorService.mapValidationError(result);
		if (errorMap != null)
			return errorMap;
		User validUser = userService.registerUser(user);
		return new ResponseEntity<User>(validUser, HttpStatus.CREATED);
	}

	/*
	 * @PostMapping("/login") public ResponseEntity<?> authenticateUser(@RequestBody
	 * User user) {
	 * 
	 * User validUser =
	 * userService.authenticateUser(user.getUserName(),user.getPwd()); return new
	 * ResponseEntity<User>(validUser, HttpStatus.OK); }
	 */

	@PatchMapping("/update")
	public ResponseEntity<?> updateUser(@Valid @RequestBody User user, BindingResult result) {
		ResponseEntity<?> errorMap = mapValidationErrorService.mapValidationError(result);
		if (errorMap != null)
			return errorMap;
		User savedUser = userService.updateUser(user);
		return new ResponseEntity<User>(savedUser, HttpStatus.CREATED);

	}

	@DeleteMapping("/delete/{userName}")
	public ResponseEntity<?> deleteUser(@PathVariable String userName) {
		{
			userService.deleteUserByUserName(userName);
			return new ResponseEntity<String>("User Deleted with User Name " + userName, HttpStatus.OK);
		}

	}

	@GetMapping("/viewallcustomer")
	public ResponseEntity<?> findAll() {
		List<User> viewAllProduct = userService.findAll();
		return new ResponseEntity<List<User>>(viewAllProduct, HttpStatus.OK);
	}

	@GetMapping("/viewbyname/{userName}")
	public ResponseEntity<?> viewUserByName(@PathVariable String userName) {

		User viewUserByName = userService.findByUserName(userName);
		return new ResponseEntity<User>(viewUserByName, HttpStatus.OK);

	}

	/*
	 * ================SECURITY CONCEPT ====================
	 * 
	 * @GetMapping("/welcome")
	 * 
	 * @PreAuthorize("hasAuthority('USER')") public String welcome() { return
	 * " Welcome to the Security"; }
	 */

	@PostMapping("/authenticate")
	public String generateToken(@RequestBody AuthRequest authRequest) throws Exception {
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword()));
		} catch (Exception ex) {
			throw new Exception("inavalid username/password");
		}
		return jwtUtil.generateToken(authRequest.getUserName());
	}

}
