package com.mms.userservice;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.mms.userservice.entities.User;
import com.mms.userservice.repository.UserRepository;

@SpringBootApplication
@EnableEurekaClient
public class UserServiceApplication {

	  @Autowired
	    private UserRepository userRepository;

	    @PostConstruct
	    public void initUsers() {
	    	User user = new User(Long.valueOf(1),"abc","pqr","swati","swati","ADMIN","asdsad","abc@gmail.com",Long.valueOf(100000));
	    	User user2 = new User(Long.valueOf(2),"xyz","pqr","swatiuser","swatiuser","USER","asdsad","abc@gmail.com",Long.valueOf(100000));
	  
	    	userRepository.save(user);
	    	userRepository.save(user2);
	    }
	
	public static void main(String[] args) {
		SpringApplication.run(UserServiceApplication.class, args);
		
		
		
	}

}
