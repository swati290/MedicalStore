package com.mms.userservice.service;

import java.util.List;

import com.mms.userservice.entities.User;

public interface UserService {

	/*
	 * method which is used for register User
	 */
	public User registerUser(User user);
	
	
	/*
	 * method which is used for Authenticate User
	 * using userName and password
	 */
//	public User authenticateUser(String userName,String pwd);
	
	

	/*
	 * method which is used for update User
	 * using user
	 */
	public User updateUser(User user);
	
	/*
	 * method which is used for delete User
	 * using userName
	 */
	public void deleteUserByUserName(String userName);
	
	
	/*
	 * method which is used for list all User
	 * 
	 */
	public List<User> findAll();


	public User findByUserName(String userName);


	
	
}
