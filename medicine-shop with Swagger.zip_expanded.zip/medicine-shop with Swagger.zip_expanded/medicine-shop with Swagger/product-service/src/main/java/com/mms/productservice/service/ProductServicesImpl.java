package com.mms.productservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.productservice.entity.Product;
import com.mms.productservice.exception.ProductAlreadyExistException;
import com.mms.productservice.exception.ProductNotFoundException;
import com.mms.productservice.repository.ProductRepository;


/**
 * This layer will execute all the business logic for the Product operations
 * @author Bhaskarrao Puppala
 *
 */
@Service
public class ProductServicesImpl implements ProductServices{
	
	//public static final Logger log = (Logger) LoggerFactory.getLogger(ProductServices.class);
	
	@Autowired
	private ProductRepository productRepository;

	private static final Logger log = LoggerFactory.getLogger(ProductServicesImpl.class);
	
	@Override
	public Product addProduct(Product product) {
		
		if(productRepository.findProductByProductIdentifier(product.getProductIdentifier()) != null) {
			log.error("Product with Identifier  "+product.getProductIdentifier()+"  already exists");
			throw new ProductAlreadyExistException("Product with Identifier  "+product.getProductIdentifier()+"  already exists");
		}
		log.info("-----------Added Product------------:Added Product Successfully");
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(Product product) {
		
		Product oldProduct  = productRepository.findProductByProductIdentifier(product.getProductIdentifier());
		product.setProductId(oldProduct.getProductId());
		oldProduct = product;
		log.info("-----------Updated Product------------:Updated Product Successfully");
		return productRepository.save(oldProduct);
	}

	@Override
	public Product viewProductByProductName(String productName) {
		
		if(productRepository.findProductByProductName(productName) == null){
			log.error("Product with  "  +productName+  "  does not exists");
			throw new ProductNotFoundException("Product with  "  +productName+  "  does not exists");
		}
		Product product = productRepository.findProductByProductName(productName);
		log.info("-----------ViewProductByName------------:View Product Successfull");
		return product;
	}

	@Override
	public List<Product> viewAllProduct() {
		
		List<Product> product = productRepository.findAll();
		log.info("-----------ViewAllProduct------------:View All Product Successfull");
		return product;
	}

	@Override
	public void deleteProductByProductIdentifier(String productIdentifier) {
		
		Product product = productRepository.findProductByProductIdentifier(productIdentifier);
		if(product == null){
			log.error("Product with   "+productIdentifier+"   does not exists");
			throw new ProductNotFoundException("Product with   "+productIdentifier+"   does not exists");
		}
		log.info("Product deleted successfully");
		productRepository.delete(product);
		
		
	}

	

}
