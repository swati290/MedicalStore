package com.mms.productservice.exception;

public class ProductAlreadyExistException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public ProductAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public ProductAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	

}
