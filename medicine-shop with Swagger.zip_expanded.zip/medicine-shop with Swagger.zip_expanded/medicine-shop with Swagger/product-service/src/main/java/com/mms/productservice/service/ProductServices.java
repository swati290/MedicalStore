package com.mms.productservice.service;

import java.util.List;

import com.mms.productservice.entity.Product;

/**
 * This layer will execute all the business logic for the Product operations
 * @author Bhaskarrao Puppala
 *
 */
public interface ProductServices {
	
	/**
	 * This method is used to add product into database
	 * @param product
	 * @return will return saved Product if entered successfully
	 */
	public Product addProduct(Product product);
	
	
	/**
	 * This method is used to update product into database if exist for admin
	 * @param product
	 * @return will return updated Product
	 */
	public Product updateProduct(Product product);
	
	
	/**
	 * This method is used to view product details for both admin and customer
	 * @param productName
	 * @return Product
	 */
	public Product viewProductByProductName(String productName);
	
	
	/**
	 * This method is used to view all products details for both admin and customer
	 * @return list of Product
	 */
	public List<Product> viewAllProduct();
	
	
	/**
	 * This method is used to delete product from database for admin when required
	 * @param productIdentifier
	 */
	public void deleteProductByProductIdentifier(String productIdentifier);

}
