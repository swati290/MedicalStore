package com.mms.productservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * This is entity class used as data transfer object between layers
 * @author Bhaskarrao Puppala
 *
 */

@Entity
@Table(name="PRODUCT_TB")
//@Data
//Getter
//setter
//@NoArgsConstructor
//@AllArgsConstructor
public class Product {
	
	
	/**
	 * Primary key of Product
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long productId;
	
	/**
	 * Name of the Product
	 */
	@NotBlank(message = "Please Enter Product name")
	@Pattern(regexp = "^[a-zA-Z ]*$", message="Name should only contain alphabets")
	private String productName;
	
	/**
	 * Unique Identifier of Product
	 */
	@Column(updatable=false,unique=true)
	@Size(min = 2, max = 6, message = "Product identifier required Size(min = 2 and Max = 6)")
	@NotBlank(message = "Product identifier is required")
	private String productIdentifier;
	
	/**
	 * Quantity of Product
	 */
	@NotNull(message = "Product quantity is required")
	private Long productQty;
	
	/**
	 * Price of Product
	 */
	@NotNull(message = "Product price is required")
	private Long productPrice;
	
	/**
	 * Description of Product
	 */
	private String description;

	

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Product(Long productId, @NotBlank(message = "Product name is required") String productName,
			@NotBlank(message = "Product identifier is required") String productIdentifier,
			@NotNull(message = "Product quantity is required") Long productQty,
			@NotNull(message = "Product price is required") Long productPrice, String description) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productIdentifier = productIdentifier;
		this.productQty = productQty;
		this.productPrice = productPrice;
		this.description = description;
	}



	public Long getProductId() {
		return productId;
	}


	public String getProductName() {
		return productName;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public Long getProductQty() {
		return productQty;
	}


	public Long getProductPrice() {
		return productPrice;
	}


	public String getDescription() {
		return description;
	}


	public void setProductId(Long productId) {
		this.productId = productId;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}


	public void setProductQty(Long productQty) {
		this.productQty = productQty;
	}


	public void setProductPrice(Long productPrice) {
		this.productPrice = productPrice;
	}


	public void setDescription(String description) {
		this.description = description;
	}



	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productIdentifier="
				+ productIdentifier + ", productQty=" + productQty + ", productPrice=" + productPrice + ", description="
				+ description + "]";
	}
	
	
	
	

    
}
