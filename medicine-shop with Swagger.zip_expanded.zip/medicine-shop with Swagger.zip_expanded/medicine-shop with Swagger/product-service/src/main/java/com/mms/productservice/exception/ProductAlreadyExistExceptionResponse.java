package com.mms.productservice.exception;

public class ProductAlreadyExistExceptionResponse {
	
	private String productIdentifier;

	
	public ProductAlreadyExistExceptionResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public ProductAlreadyExistExceptionResponse(String productIdentifier) {
		super();
		this.productIdentifier = productIdentifier;
	}


	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

}
