package com.mms.productservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mms.productservice.entity.Product;

/**
 * This is used to perform all Prooduct related CRUD operations on the Product
 * @author Bhaskarrao Puppala
 *
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long>{
	
	/**
	 * This method is used to search the Product by its name 
	 * @param productName
	 * @return Product
	 */
	public Product findProductByProductName(String productName);
	
	/**
	 * This method is used to search the Product by its unique identifier
	 * @param productIdentifier
	 * @return Product
	 */
	public Product findProductByProductIdentifier(String productIdentifier);

}
