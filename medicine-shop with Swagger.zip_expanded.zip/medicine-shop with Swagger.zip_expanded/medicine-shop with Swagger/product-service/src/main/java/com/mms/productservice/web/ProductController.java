package com.mms.productservice.web;

import java.util.List;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mms.productservice.entity.Product;
import com.mms.productservice.service.MapValidationErrorService;
import com.mms.productservice.service.ProductServices;


/**
 * Product Controller is used to navigate url request and send the response
 * 
 * @author Bhaskarrao Puppala
 *
 */

@RestController
@RequestMapping("/productservice/api")
@CrossOrigin
public class ProductController {
	
	
	@Autowired
	private ProductServices productServices;
	
	@Autowired
	private MapValidationErrorService mapValidationErrorService;
	
	/**
	 * This method is used to add product into database
	 * @param product
	 * @param result
	 * @return Response Entity with new added Product
	 */
	@PostMapping("/addproduct")
	public ResponseEntity<?> addProduct(@Valid @RequestBody Product product,BindingResult result){
		ResponseEntity<?> errorMap = mapValidationErrorService.mapValidationError(result);
		if (errorMap != null)
			return errorMap;
		Product addUpProduct = productServices.addProduct(product);
		return new ResponseEntity<Product>(addUpProduct, HttpStatus.CREATED);
		
	}
	
	
	/**
	 * This method is used to update product into database if exist
	 * @param product
	 * @param result
	 * @return Response Entity with updated Product
	 */
	@PatchMapping("/update")
	public ResponseEntity<?> updateProduct(@Valid @RequestBody Product product,BindingResult result){
		ResponseEntity<?> errorMap = mapValidationErrorService.mapValidationError(result);
		if (errorMap != null)
			return errorMap;
		Product updateProduct = productServices.updateProduct(product);
		return new ResponseEntity<Product>(updateProduct, HttpStatus.OK);
		
	}
	
	
	/**
	 * This method is used to view product details from database
	 * @param productName
	 * @return Response Entity with Product
	 */
	@GetMapping("/viewbyname/{productName}")
	public ResponseEntity<?> viewProductByName(@PathVariable String productName){
		Product viewProductByName = productServices.viewProductByProductName(productName);
		return new ResponseEntity<Product>(viewProductByName,HttpStatus.OK);
		
	}
	
	
	
	/**
	 * This method is used to view all products details from database
	 * @return Response Entity with list of Product
	 */
	@GetMapping("/viewallproduct")
	public ResponseEntity<?> viewAllProduct(){
		List<Product> viewAllProduct = productServices.viewAllProduct();
		return new ResponseEntity<List<Product>>(viewAllProduct,HttpStatus.OK);
	}
	
	
	
	/**
	 * This method is used to delete product from database when required
	 * @param productIdentifier
	 * @return Response Entity with message Product deleted successfully
	 */ 
	@DeleteMapping("delete/{productIdentifier}")
	public ResponseEntity<?> deleteProduct(@PathVariable String productIdentifier){
		productServices.deleteProductByProductIdentifier(productIdentifier);
		return new ResponseEntity<String>("Product deleted successfully", HttpStatus.OK);
	}
	

}
