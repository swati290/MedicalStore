package com.mms.productservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mms.productservice.entity.User;
import com.mms.productservice.entity.UserDetail;


@Service
public class CustomUserDetailsService  implements UserDetailsService{


	 @Autowired
	    private RestTemplate restTemplate;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		// User user = userRepository.findByUserName(username);
		User user = (User) restTemplate.getForObject("http://USER-SERVICE/userservice/api/viewbyname/"+username, User.class);
		System.out.println("User = "+ user);
		 return new UserDetail(user);
	}

}
