package com.mms.productservice.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mms.productservice.entity.Product;
import com.mms.productservice.exception.ProductAlreadyExistException;
import com.mms.productservice.exception.ProductNotFoundException;
import com.mms.productservice.repository.ProductRepository;
import com.mms.productservice.service.ProductServicesImpl;


class ProductServiceImplTestCases {

	@Mock
	private ProductRepository productRepository;
	
	@InjectMocks
	private ProductServicesImpl productServicesImpl;
	
	
	@BeforeEach
	void setUp() throws Exception {

	MockitoAnnotations.openMocks(this);// invoke mocks
	
	}
	

	@Test
	@Order(1)
	public void test_AddProduct_GivenProduct_ShouldReturnAddedProduct() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.save(product)).thenReturn(product);
		assertEquals(product,productServicesImpl.addProduct(product));
	}
	
	@Test
	@Order(2)
	public void test_AddProduct_GivenProductAlreadyExist_ShouldThrowProductAlreadyExistException() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
        when(productRepository.findProductByProductIdentifier(product.getProductIdentifier())).thenReturn(product);
        assertThrows(ProductAlreadyExistException.class, () -> productServicesImpl.addProduct(product));
	}
	
	@Test
	@Order(3)
	public void test_UpdateProduct_GivenProduct_ShouldReturnUpdatedProduct() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.findProductByProductIdentifier(product.getProductIdentifier())).thenReturn(product);
		when(productRepository.save(product)).thenReturn(product);
		assertEquals(product,productServicesImpl.updateProduct(product));
	}
	
	@Test
	@Order(4)
	public void test_UpdateProductName_GivenProduct_ShouldReturnUpdatedProductName() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.findProductByProductIdentifier(product.getProductIdentifier())).thenReturn(product);
		when(productRepository.save(product)).thenReturn(product);
		assertEquals(product.getProductName(),productServicesImpl.updateProduct(product).getProductName());
	}
	
	@Test
	@Order(5)
	public void test_ViewProductByName_GivenProduct_ShouldReturnProduct() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.findProductByProductName(product.getProductName())).thenReturn(product);
		assertEquals(product,productServicesImpl.viewProductByProductName(product.getProductName()));
	}
	
	@Test
	@Order(6)
	public void test_ViewProductByName_GivenProductName_ShouldReturnProductNotFoundException() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.findProductByProductName(product.getProductName())).thenReturn(null);
		assertThrows(ProductNotFoundException.class, () -> productServicesImpl.viewProductByProductName(product.getProductName()));
	}
	
	@Test
	@Order(7)
	public void test_ViewAllProduct_ShouldReturnListOfProduct() {
		List<Product> product = new ArrayList<Product>();
		product.add(new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain"));
		product.add(new Product(Long.valueOf(1),"Panadol","M02",Long.valueOf(42),Long.valueOf(60),"Used to cure fever,body pain"));
		when(productRepository.findAll()).thenReturn(product);
		assertEquals(product,productServicesImpl.viewAllProduct());
	}
	
	@Test
	@Order(8)
	public void test_DeleteProduct_GivenProductIdentifier_ShouldReturnString() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.findProductByProductIdentifier(product.getProductIdentifier())).thenReturn(product);
		productServicesImpl.deleteProductByProductIdentifier(product.getProductIdentifier());
		verify(productRepository, times(1)).delete(product);
	}
	
	
	@Test
	@Order(9)
	public void test_DeleteProduct_GivenProductIdentifierNotExist_ShouldReturnProductNotFoundException() {
		Product product = new Product(Long.valueOf(1),"Crocin","M01",Long.valueOf(22),Long.valueOf(222),"Used to cure fever,body pain");
		when(productRepository.findProductByProductIdentifier(product.getProductIdentifier())).thenReturn(null);
		assertThrows(ProductNotFoundException.class, ()  -> productServicesImpl.deleteProductByProductIdentifier(product.getProductIdentifier()));
	}
	
	
}
